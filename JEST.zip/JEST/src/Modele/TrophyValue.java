package Modele;

public enum TrophyValue {
	

}
