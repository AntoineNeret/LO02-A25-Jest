package Modele;

public class CarteExtension extends Carte{
	private String effetCarte;
	
	public CarteExtension() {
		
	}
	
	public void appliquerEffet() {
		
	}
}
