package Modele;

public class InputNotDefined extends Exception{

	public InputNotDefined (String msg) {
		super(msg);
	}
}
