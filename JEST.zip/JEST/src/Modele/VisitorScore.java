package Modele;

public interface VisitorScore {
	public int visiter(Joueur j);
	
}
