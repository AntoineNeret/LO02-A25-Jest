package Modele;
import java.util.*;
public class Paquet {

	public List<Carte> cartes = new ArrayList<>();
	
	public void ajouterCarte(Carte c) {
		this.cartes.add(c);
	}
	
	public void retirerCarte(Carte c) {
		
	}
	
	public List<Carte> getCartes(){
		return cartes;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
